"""Actual Sod limiter records plus explicit software-only retry injection."""
from pathlib import Path
import json
import numpy as np
import driver
from dino2next.numerics import NumericalKernel,StepAttempt

OUT=Path(__file__).resolve().parent
case={'name':'software-storage-sod-with-injected-retry','time':.003}
baseline=driver.load('sod_original',driver.CANONICAL)
original=NumericalKernel.propose_step
results=[]
try:
    for name,execute in [('original',baseline.execute),('streamed',driver.execute)]:
        calls=[0]
        def injected(self,*args,**kwargs):
            calls[0]+=1
            if calls[0]==1:
                return StepAttempt(None,'LOW_ORDER_STAGE_INADMISSIBLE_RETRY_DT',
                                   (('SOFTWARE_TEST_INJECTED_REJECTION',-0.,1e-300),))
            return original(self,*args,**kwargs)
        NumericalKernel.propose_step=injected
        results.append(execute('VAL-006',40,case,.05,output_root=OUT/('control-'+name))[0])
finally:
    NumericalKernel.propose_step=original
old,new=results
assert old['metrics']==new['metrics']
counts={}
for key in ('steps','rejections','limiter_records'):
    traces=list(driver.events(OUT/'control-streamed',new[key]))
    assert traces==json.loads(json.dumps(old[key]))
    counts[key]=len(traces)
assert counts['rejections']==1 and counts['limiter_records']>0
stem=case['name']+'-N40-CFL0.05.npz'
a=np.load(OUT/'control-original'/stem);b=np.load(OUT/'control-streamed'/stem)
for key in a.files:assert a[key].tobytes()==b[key].tobytes()
report=dict(classification='SOFTWARE_ONLY_RETRY_INJECTION_AND_ACTUAL_LIMITER_STORAGE_TEST',
    counts=counts,all_raw_arrays_bitwise=True,all_metrics_and_traces_equal=True,
    driver_sha256=driver.digest(OUT/'driver.py'),test_sha256=driver.digest(Path(__file__)))
(OUT/'control-path-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
