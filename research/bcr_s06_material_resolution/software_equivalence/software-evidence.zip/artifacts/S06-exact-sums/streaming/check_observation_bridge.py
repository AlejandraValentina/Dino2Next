"""Reference/assessment wiring only: no evolved candidate, no acceptance."""
from pathlib import Path
import json
import numpy as np
import driver

OUT=Path(__file__).resolve().parent
path=Path('/mnt/e/dino2/Dino2Next-S06-MR/research/bcr_s06_material_resolution/acoustic/observation.py')
observation=driver.load('observation_bridge',path)
assessment=driver.load('assessment_bridge',driver.ROOT/'validation/fixtures/VAL-006/assessment.py')
d=driver.load('canonical_bridge',driver.CANONICAL)
fixture=json.loads((driver.ROOT/'validation/fixtures/VAL-010/input.json').read_text())
counts=[]
for epsilon in (1e-5,5e-6):
    case=next(c for c in fixture['cases'] if c['kind']=='free' and c['epsilon']==epsilon)
    k,state,ref=d.setup('VAL-010',1600,case)
    for i,t in enumerate(np.linspace(0,case['time'],101)):
        certified=observation.observation_reference(1600,i,epsilon)
        values=ref.cell_averages(state.mesh.cell_bounds,float(t),**d.reference_parameters(case))
        primitives=np.column_stack([values[name] for name in ('rho','u','p')])
        result=assessment.assess_reflection_sample(ref,state.mesh.cell_bounds,primitives,certified,1600,float(t),i)
        assert result['sample_index']==i and set(result['components'])=={'incident','reflected','pressure'}
    counts.append({'epsilon':epsilon,'samples':101})
report={'classification':'REFERENCE_ASSESSMENT_WIRING_ONLY_NO_EVOLVED_CANDIDATE',
    'all_calls_completed':True,'counts':counts,'observation_sha256':driver.digest(path),
    'qualification_sha256':driver.digest(path.with_name('free_observation_qualification.json')),
    'assessment_sha256':driver.digest(driver.ROOT/'validation/fixtures/VAL-006/assessment.py')}
(OUT/'observation-bridge-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
