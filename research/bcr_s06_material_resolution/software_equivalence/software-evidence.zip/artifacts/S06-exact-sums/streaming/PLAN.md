# Streaming evidence storage only

Owned directory: artifacts/S06-exact-sums/streaming. No production source changes. Preserve canonical execute arithmetic, targets, ledgers and retry logic through exact source substitutions limited to storage. Keep boundary/source/throughput lists to preserve original compensated summation bitwise; the large per-face diagnostic lists become gzip JSONL append sinks. Retain all 101 state samples in original NPZ format.

Pilot: original execute versus storage-adapted execute, N40 and explicit shortened software-only case, all 101 targets; compare every raw array bit pattern, final Q, metrics, and serialized step/rejection/limiter diagnostics. The shortened case is not fixture acceptance. No N1600 trajectory is launched. Experimental assessment invokes original reflection operators with MR/acoustic/observation.py and its qualified record, preserving all samples/masks/errors. N1600 remains outside accepted R4 obligations until adjudication.

Memory still includes 101 state snapshots and scalar per-step ledger arrays. This is O(101*N + steps*12), not constant memory; it removes the O(steps*N) diagnostic accumulation. Gzip output is lossless JSON, compressed and uncompressed hashes/counts are checked. Exceptions retain closed partial streams with explicit failure/interruption status.

Command: Ubuntu WSL, PYTHONPATH=<PERF>/src, GIT_DIR=<main>/.git/worktrees/Dino2Next-S06-PERF and GIT_WORK_TREE=<PERF>; foundationvenv/bin/python artifacts/S06-exact-sums/streaming/pilot.py. Review ownership is author validation, not independent approval.
