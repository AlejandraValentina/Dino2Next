"""101-sample bounded storage equivalence, shortened software case explicit."""
from pathlib import Path
import json,time,resource
import numpy as np
import driver

OUT=Path(__file__).resolve().parent
d=driver.load('original_for_stream_test',driver.CANONICAL)
case=json.loads((driver.ROOT/'validation/fixtures/VAL-010/input.json').read_text())['cases'][2].copy()
case['time']=.003
case['name']='software-storage-pilot-shortened-free'
# This is an explicit software-only setup, never a qualified fixture mutation.
start=time.perf_counter();old,so,_=d.execute('VAL-010',40,case,.05,output_root=OUT/'original')
old_elapsed=time.perf_counter()-start
start=time.perf_counter();new,sn,_=driver.execute('VAL-010',40,case,.05,output_root=OUT/'streamed')
new_elapsed=time.perf_counter()-start
stem=f"{case['name']}-N40-CFL0.05"
a=np.load(OUT/'original'/(stem+'.npz'));b=np.load(OUT/'streamed'/(stem+'.npz'))
assert a.files==b.files
for key in a.files:
    assert a[key].dtype==b[key].dtype and a[key].shape==b[key].shape
    assert a[key].tobytes()==b[key].tobytes(),key
assert so.Q.tobytes()==sn.Q.tobytes()
for key in ('metrics','case','N','CFL','fixture','environment','commit','hashes','result'):
    assert old[key]==new[key],key
counts={}
for key in ('steps','rejections','limiter_records'):
    streamed=list(driver.events(OUT/'streamed',new[key]))
    # Original diagnostics tuples acquire their published JSON list form.
    assert json.loads(json.dumps(old[key]))==streamed,key
    counts[key]=len(streamed)
assert len(new['metrics'])==101
report=dict(classification='AUTHOR_BOUNDED_STORAGE_EQUIVALENCE_NOT_NUMERICAL_ACCEPTANCE',
    bitwise_arrays=True,bitwise_final_state=True,all_metrics_equal=True,
    all_step_rejection_limiter_diagnostics_equal=True,counts=counts,samples=101,
    explicit_software_case=case,old_elapsed_seconds=old_elapsed,stream_elapsed_seconds=new_elapsed,
    process_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    driver_sha256=driver.digest(OUT/'driver.py'),pilot_sha256=driver.digest(Path(__file__)),
    canonical_sha256=driver.digest(driver.CANONICAL),kernel_sha256=driver.digest(driver.ROOT/'src/dino2next/numerics/__init__.py'))
(OUT/'pilot-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
