from pathlib import Path
import gzip,json,tempfile
import numpy as np
import driver

h=Path(__file__).resolve().parent
assert driver.digest(h/'driver.py')=='52dc412ad7b2d35b24c0bbf02edf09030e00e95d6df0f5c2731741f179096a61'
checked=[]
for original,stream in [('original','streamed'),('control-original','control-streamed')]:
    oldpath=next((h/original).glob('*.json'));newpath=h/stream/oldpath.name
    a=json.loads(oldpath.read_text());b=json.loads(newpath.read_text())
    assert a['metrics']==b['metrics']
    for key in ('steps','rejections','limiter_records'):
        rows=list(driver.events(h/stream,b[key]));assert rows==a[key]
        # Compare IEEE values through canonical serialization as well as equality.
        assert json.dumps(rows,sort_keys=True)==json.dumps(a[key],sort_keys=True)
    ra=oldpath.with_suffix('.npz');rb=newpath.with_suffix('.npz')
    assert driver.digest(ra)==a['raw_sha256'] and driver.digest(rb)==b['raw_sha256']
    with np.load(ra) as x,np.load(rb) as y:
        assert x.files==y.files
        for key in x.files:assert x[key].dtype==y[key].dtype and x[key].shape==y[key].shape and x[key].tobytes()==y[key].tobytes()
    checked.append({'case':a['case']['name'],'samples':len(a['metrics']),'trace_counts':{k:b[k]['count'] for k in ('steps','rejections','limiter_records')}})
with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp)/'trace.gz';s=driver.Sink(p);s.append({'signed_zero':-0.0,'subnormal':float.fromhex('0x0.0000000000001p-1022')});m=s.manifest();s.close()
    assert len(list(driver.events(tmp,m)))==1
    bad=dict(m,count=m['count']+1)
    try:list(driver.events(tmp,bad))
    except AssertionError:pass
    else:raise AssertionError('count corruption undetected')
    data=p.read_bytes();p.write_bytes(data[:-1]+bytes([data[-1]^1]))
    try:list(driver.events(tmp,m))
    except AssertionError:pass
    else:raise AssertionError('payload corruption undetected')
report={'reviewer':'/root','independent_of':'s03_runtime_builder author','verdict':'APPROVE_STORAGE_ONLY_EXPERIMENTAL_DRIVER','checks':checked,'count_and_payload_corruption_detected':True,'driver_sha256':driver.digest(h/'driver.py'),'runner_sha256':driver.digest(h/'run.py'),'canonical_sha256':driver.digest(driver.CANONICAL),'kernel_sha256':driver.digest(driver.ROOT/'src/dino2next/numerics/__init__.py'),'published_equivalent_commit':'2d04c16fc77b603596f7db04a8ed7d35953afa17','findings':[],'limits':['No full numerical acceptance. Assessment bridge uses newly qualified N1600 reference with original observation operators.','Original loop, compensated terms, retry and101target sampling retained by exact source substitutions independently read. Diagnostics JSON numeric content retained; formatting/storage differ.','NaN/non-JSON traces fail explicitly; interrupted runs never count as PASS. Source hashes checked before/after execution.']}
(h/'independent-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
