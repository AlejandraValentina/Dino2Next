from pathlib import Path
from hashlib import sha256
from math import fsum
import ast,json,struct,itertools
import numpy as np
import dino2next.numerics as module
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
source=ROOT/'src/dino2next/numerics/__init__.py'
assert Path(module.__file__).resolve()==source.resolve()
def digest(p):return sha256(p.read_bytes()).hexdigest()
assert digest(source)=='84e5fba185fabf8008936c6ca533d0610b8cb87aa87b48833cf3d821328bfac9'
a=ast.parse((HERE/'original_numerics.py').read_text());b=ast.parse(source.read_text())
klass=next(x for x in b.body if isinstance(x,ast.ClassDef) and x.name=='NumericalKernel')
klass.body=[x for x in klass.body if not (isinstance(x,ast.FunctionDef) and x.name=='_fraction_sums')]
recover=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='recover')
for x in ast.walk(recover):
 if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='sums':
  x.value=ast.parse('np.asarray([fsum(row) for row in values])',mode='eval').body
assert ast.dump(a)==ast.dump(b),'Unexpected AST change'
rng=np.random.default_rng(812923);tested=0
for width in (4,5):
 vals=rng.integers(0,0x7ff0000000000000,size=(20000,width),dtype=np.uint64).view(np.float64)
 vals[rng.random(vals.shape)<.8]=-0.
 rows=[]
 for row in vals:
  try:fsum(row)
  except OverflowError:continue
  rows.append(row)
 # Exhaustive combinations of signed zero and least subnormal.
 rows.extend(itertools.product((0.,-0.,np.nextafter(0.,1.)),repeat=width))
 rows.extend([[float('inf')]+[-0.]*(width-1),[float('inf'),1.]+[0.]*(width-2)])
 vals=np.array(rows);before=vals.tobytes()
 expected=np.array([fsum(row) for row in vals]);actual=module.NumericalKernel._fraction_sums(vals)
 assert actual.tobytes()==expected.tobytes();assert vals.tobytes()==before;tested+=len(vals)
report=json.loads((HERE/'pilot-report.json').read_text())
assert report['candidate_source_sha256']==digest(source)
assert report['baseline_source_sha256']==digest(HERE/'original_numerics.py')
assert report['script_sha256']==digest(HERE/'pilot.py')
arrays=0
for case in report['cases']:
 traces=[];raws=[]
 for run in case['results']:
  prefix=case['kind']+'-'+run['label'];trace=HERE/(prefix+'-trace.json');raw=HERE/(prefix+'.npz')
  assert digest(trace)==run['trace_sha256'];assert digest(raw)==run['raw_sha256']
  traces.append(json.loads(trace.read_text()));raws.append(np.load(raw))
 assert traces[0]==traces[1]
 assert raws[0].files==raws[1].files
 for name in raws[0].files:
  x,y=raws[0][name],raws[1][name]
  assert x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes();arrays+=1
print(json.dumps({'rows_bitwise':tested,'pilot_arrays_bitwise':arrays,'AST_only_authorized_change':True,'candidate_sha256':digest(source)},indent=2))
