"""Author-side bounded bitwise equivalence; no numerical gate acceptance."""
from pathlib import Path
from hashlib import sha256
from dataclasses import fields,is_dataclass
import importlib.util,sys,json,time,struct,subprocess
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def digest(p):return sha256(p.read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m
baseline='cc5c4ed66a2f8ea94cdeeeeeb32aa39e6dceb161'
original=OUT/'original_numerics.py'
original.write_bytes(subprocess.check_output(['git','--git-dir=/mnt/e/dino2/Dino2Next/.git','show',baseline+':src/dino2next/numerics/__init__.py']))
old=load('sparse_original',original)
import dino2next.numerics as new
source=ROOT/'src/dino2next/numerics/__init__.py';source_hash=digest(source)
assert Path(new.__file__).resolve()==source.resolve()
def signature(v,arrays,path='root'):
    if isinstance(v,np.ndarray):
        arrays[path]=v
        return ('array',v.dtype.str,v.shape,sha256(v.tobytes()).hexdigest())
    if is_dataclass(v):return (type(v).__name__,[(f.name,signature(getattr(v,f.name),arrays,path+'.'+f.name)) for f in fields(v)])
    if isinstance(v,dict):return [(str(k),signature(x,arrays,path+'.'+str(k))) for k,x in v.items()]
    if isinstance(v,(tuple,list)):return [signature(x,arrays,path+'.'+str(i)) for i,x in enumerate(v)]
    if isinstance(v,(float,np.floating)):return ('float64',struct.pack('!d',float(v)).hex())
    if isinstance(v,np.generic):return v.item()
    return v

report={'classification':'AUTHOR_SOFTWARE_EQUIVALENCE_NOT_INDEPENDENT_REVIEW_OR_NUMERICAL_ACCEPTANCE',
        'baseline_commit':baseline,'baseline_source_sha256':digest(original),'candidate_source_sha256':source_hash,'cases':[]}
for kind in ('gamma30','NASA1'):
    results=[];signatures=[]
    for label,module in [('original',old),('sparse',new)]:
        arrays={};sigs=[];start=time.perf_counter()
        if kind=='gamma30':
            d=load('gamma_driver_'+label,ROOT/'validation/fixtures/VAL-006/canonical_execution.py')
            d.NumericalKernel=module.NumericalKernel;d.StageRHS=module.StageRHS
            case=json.loads((ROOT/'validation/fixtures/VAL-010/input.json').read_text())['cases'][2]
            k,state,ref=d.setup('VAL-010',1600,case);rhs=d.CanonicalRHS(k,'VAL-010',case,ref)
            steps=30
        else:
            d=load('nasa_driver_'+label,ROOT/'validation/fixtures/VAL-008/execution.py')
            d.NumericalKernel=module.NumericalKernel;d.StageRHS=module.StageRHS
            f=d.verify_fixture();ref=d.load_reference();case=f['cases'][7];n=f['meshes'][case['kind']][0]
            solution=ref.solve(ref.Case(**case['parameters']));mesh,_=d.guarded_mesh(n,f['guard_speeds'][case['kind']],case['time'])
            initial=solution.cell_averages(mesh.cell_bounds,0.)
            k=d.kernel();state=k.state(mesh,initial['conserved']);rhs=d.GuardedRHS(k,state,f['guard_speeds'][case['kind']]);steps=1
            faces=k.reconstruct(state,boundary='physical',ghosts=(rhs.left,rhs.right))
            flux=k.interior_flux(faces,boundary_flux=rhs.boundary)
            sigs.append(signature((faces,flux),arrays,'faces_flux'))
        setup_seconds=time.perf_counter()-start
        sigs.append(signature(state,arrays,'initial'));t=0.;step_start=time.perf_counter()
        for index in range(steps):
            v=k.recover(state.Q)
            dt=float((.05 if kind=='gamma30' else .2)*np.min(np.asarray(state.mesh.dx)/(abs(v.V[:,1])+v.a)))
            if kind=='NASA1':dt=min(dt,case['time']/100)
            attempt=k.propose_step(state,rhs,t,dt)
            sigs.append(signature((index,t,dt,v,attempt),arrays,'step'+str(index)))
            assert attempt.accepted,(kind,label,index,attempt.rejection)
            state=attempt.state;t+=dt
        seconds=time.perf_counter()-step_start
        if kind=='NASA1':sigs.append(signature(rhs.stage_speeds,arrays,'stage_speeds'))
        raw=OUT/f'{kind}-{label}.npz';np.savez_compressed(raw,**arrays)
        trace=OUT/f'{kind}-{label}-trace.json'
        trace.write_text(json.dumps(sigs,indent=2)+'\n')
        signatures.append(sigs)
        results.append({'label':label,'setup_seconds':setup_seconds,'steps_seconds':seconds,
            'step_count':steps,'arrays':len(arrays),'raw_sha256':digest(raw),'trace_sha256':digest(trace),
            'signature_sha256':sha256(json.dumps(sigs).encode()).hexdigest()})
        print(kind,label,seconds,'seconds',len(arrays),'arrays',flush=True)
    assert signatures[0]==signatures[1],kind+' BITWISE_MISMATCH'
    report['cases'].append({'kind':kind,'case':case,'bitwise_equal':True,'results':results,
                          'speedup':results[0]['steps_seconds']/results[1]['steps_seconds']})
    assert digest(source)==source_hash,'SOURCE_CHANGED'
    (OUT/'pilot-report.json').write_text(json.dumps(report,indent=2)+'\n')
report['result']='BOUNDED_EQUIVALENCE_VERIFIED';report['script_sha256']=digest(Path(__file__))
(OUT/'pilot-report.json').write_text(json.dumps(report,indent=2)+'\n')
