# Bounded software equivalence validation

Owner /root/s03_runtime_builder; not independent review. Own tests/unit/s06/test_fraction_sums.py and this artifacts directory only. Runtime is frozen by parent. Baseline: git cc5c4ed66a2f8ea94cdeeeeeb32aa39e6dceb161 numerical module. Candidate: current worktree numerical module; only parent's sparse nonnegative fsum optimization is authorized.

Checks: adversarial signed-zero/subnormal/dense/exponent-spread rows against original math.fsum bitwise; immutable input and invalid recovery exclusion; N1600 free acoustic case 30 actual steps and coarse NASA one actual step. Compare initial/face/flux/attempt states, ledgers, diagnostic values and time steps with float bit patterns and raw-array hashes. Load original as a separate module and inject its StageRHS into driver, preserving type identity. This does not accept numerical fixtures or reuse previous acceptance automatically.

Environment: Ubuntu WSL Python3.12 foundationvenv, PYTHONPATH=/mnt/e/dino2/Dino2Next-S06-PERF/src. No runtime edits, commits or full numerical campaign.
